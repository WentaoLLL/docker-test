define({
  "title": "接口文档",
  "url": "http://localhost:3000",
  "name": "nodetest1-2018",
  "version": "0.0.0",
  "description": "",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-05-29T10:50:06.441Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
