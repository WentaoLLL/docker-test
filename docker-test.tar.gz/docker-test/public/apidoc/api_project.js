define({
  "title": "Api-Doc",
  "url": "http://localhost:3000",
  "name": "nodetest1-2018",
  "version": "0.0.0",
  "description": "",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-05-30T00:15:58.647Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
